import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postpaidtariff',
  templateUrl: './postpaidtariff.component.html',
  styleUrls: ['./postpaidtariff.component.scss']
})
export class PostpaidtariffComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
