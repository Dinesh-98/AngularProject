import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paybills',
  templateUrl: './paybills.component.html',
  styleUrls: ['./paybills.component.scss']
})
export class PaybillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
