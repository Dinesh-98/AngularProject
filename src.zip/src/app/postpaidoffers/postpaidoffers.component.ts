import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postpaidoffers',
  templateUrl: './postpaidoffers.component.html',
  styleUrls: ['./postpaidoffers.component.scss']
})
export class PostpaidoffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
