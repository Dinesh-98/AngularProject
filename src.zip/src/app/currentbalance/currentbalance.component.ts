import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-currentbalance',
  templateUrl: './currentbalance.component.html',
  styleUrls: ['./currentbalance.component.scss']
})
export class CurrentbalanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
