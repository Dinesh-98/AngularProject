import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaidtariff',
  templateUrl: './prepaidtariff.component.html',
  styleUrls: ['./prepaidtariff.component.scss']
})
export class PrepaidtariffComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
