import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addmoneywallet',
  templateUrl: './addmoneywallet.component.html',
  styleUrls: ['./addmoneywallet.component.scss']
})
export class AddmoneywalletComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
