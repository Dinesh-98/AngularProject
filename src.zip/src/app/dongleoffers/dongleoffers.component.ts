import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dongleoffers',
  templateUrl: './dongleoffers.component.html',
  styleUrls: ['./dongleoffers.component.scss']
})
export class DongleoffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
