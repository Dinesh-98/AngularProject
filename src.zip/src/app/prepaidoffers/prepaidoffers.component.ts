import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaidoffers',
  templateUrl: './prepaidoffers.component.html',
  styleUrls: ['./prepaidoffers.component.scss']
})
export class PrepaidoffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
