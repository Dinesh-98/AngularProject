import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-internettariff',
  templateUrl: './internettariff.component.html',
  styleUrls: ['./internettariff.component.scss']
})
export class InternettariffComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
